#!/usr/bin/env python3
"""Replay numeric cost only. Never substitutes for the blocked S3 acceptance gate."""
import argparse, json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);a=p.parse_args();r=a.bundle
m=json.loads((r/'baseline102.json').read_text());params=json.loads((r/'parameters.json').read_text());done=json.loads((r/'completed.json').read_text())
assert params['pid']==m['resident']['pid'] and params['startTicks']==m['resident']['startTicks'] and params['executableSha256']==m['resident']['sha256']
assert params['build']==m['build'] and not m['build']['dirty'] and done['residentIdentityUnchanged']
rows=[json.loads(x) for x in (r/'samples.jsonl').read_text().splitlines()];q=[x for x in rows if x['stage']==m['quietStage']];assert q
q=[x for x in q if x['elapsedSeconds']>=q[0]['elapsedSeconds']+5];chosen=[]
for x in q:
    chosen.append(x)
    if x['elapsedSeconds']-chosen[0]['elapsedSeconds']>=300:break
duration=chosen[-1]['elapsedSeconds']-chosen[0]['elapsedSeconds'];assert duration>=300
maxgap=max(b['elapsedSeconds']-a['elapsedSeconds'] for a,b in zip(chosen,chosen[1:]));assert maxgap<=2.5
diag=[x['diagnostics'] for x in chosen if 'diagnostics' in x];assert len(diag)>=29
def resident(x):
    found=[v for v in x['family'] if v['pid']==m['resident']['pid'] and v['startTicks']==m['resident']['startTicks']];assert len(found)==1;return found[0]
rss=max(sum(v['memoryBytes']['Rss']+v['memoryBytes'].get('Swap',0) for v in x['family']) for x in chosen)/1048576
swap=max(sum(v['memoryBytes'].get('Swap',0) for v in x['family']) for x in chosen)/1048576
cpu=(resident(chosen[-1])['cpuTicks']-resident(chosen[0])['cpuTicks'])/params['clockTicksPerSecond']/duration*100
family=max(len(x['family']) for x in chosen);ui=max(x['ui']['pid'] for x in diag);active=max(x['activeOperations'] for x in diag)
assert rss<=40 and swap==0 and cpu<.5 and family==1 and ui==0 and active==0
result={'sourceCommit':m['build']['gitCommit'],'version':m['build']['version'],'fixedQuietSeconds':duration,'quietSamples':len(chosen),'diagnosticSamples':len(diag),'sampleMaxGapSeconds':maxgap,'rssPlusSwapMiB':rss,'swapMiB':swap,'idleCpuPercentOneCore':cpu,'familyMax':family,'uiPidMax':ui,'activeOperationsMax':active,'memoryNumericGatePassed':True,'overallLiveAcceptancePassed':False,'scope':'Numeric-only replay; production cleanup gate remains blocked. No guest/network/credential access.'}
print(json.dumps(result))
