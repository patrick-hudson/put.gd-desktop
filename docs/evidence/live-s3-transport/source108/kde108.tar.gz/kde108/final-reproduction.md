# KDE source 108 diagnostic receipts

Current package/source identity is recorded in `candidate.json`; 57 native tests,
package audit and real native 12 plus GUI 8 passed. `final-kde-result.json` describes
the complete live upload run and its blocked production deletion gate.

The live workload completed 30 operations and 31 objects across all six sources.
All public bytes, native URL pastes and 15 region pixel oracles passed. The fixed
first 5 seconds of warmup followed by the first 300 seconds of quiet measured
31.37890625 MiB RSS plus swap, zero swap and 0.01332885% of one core.

Replay saved numeric samples without guest, network, credentials or current source:

```bash
python3 replay_numeric_memory.py --bundle a1
```

The original `live-prepared/evaluate.py --bundle a1` intentionally cannot pass:
production History removed 23 targets and persisted 8 unknown results. No fake
`cleanup-completed.json` or accepted evaluator result was created. The 8 unknowns
all recorded SDK error 99/curl 35/no HTTP response, in 108–154 ms, across five HEAD
and three DELETE stages. The underlying TLS reason remains unknown.

Emergency cleanup used current authenticated publication/hash/size/ETag/version
proof plus conditional deletion and authenticated post-HEAD 404. Eight targets
were removed this way; these are separate from production acceptance. All 31
owned local copies and 30 completed spools were cleared. History/deletion journal
states remain unchanged. The visible fixture and resident exited normally;
the owned product family is empty and source 108 pin is released.

Preserved qualifications:

- First native Escape operation cancelled correctly but its paste witness SCP
  failed. One authorized unchanged full 12-case repeat passed. Late witness
  metadata does not replace the failed original receipt.
- A new supplemental log scaffold matched its own sanitized output. Original
  bytes, failure and successful batch receipts remain; the corrected filter
  resumed only uninvoked actions, with an extra recorded text-to-region pause.
- Process telemetry recorded 107 identities, but no actual zombie exit statuses.
  Disappearance is not an independently observed normal exit. The production
  typed-result normal-exit guard is a separate source guarantee.
- No desktop power/compositor settings, dependencies or VM disks were changed.

Keep all original failure files. Compressed numeric export follows global source
pin release and excludes credentials, payload bodies, screenshots and raw SDK
messages/headers. Exact hashes are in `final-evidence-index.json` and each receipt.
