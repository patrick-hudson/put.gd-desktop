import argparse,json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from bench_ui_process import ProcessFamily,identity,same_identity
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--ticks',type=int,required=True);p.add_argument('--output',required=True);a=p.parse_args()
out=Path(a.output);out.mkdir(mode=0o700,exist_ok=False);family=ProcessFamily(a.pid,'/usr/bin/putgd','/usr/bin/putgd-ui',a.ticks)
started=time.monotonic();result={'passed':False,'resident':family.root,'samples':0,'windows':{}}
try:
 with (out/'samples.jsonl').open('x') as stream:
  while not (out.parent/'watch-stop').exists():
   sample=family.sample();phase=(out.parent/'phase').read_text().strip();helpers=[]
   for proc in Path('/proc').iterdir():
    if not proc.name.isdecimal():continue
    try:
     if proc.stat().st_uid!=os.getuid():continue
     exe=os.readlink(proc/'exe');name=Path(exe).name
     if name.startswith('putgd') and int(proc.name)!=a.pid and name not in ['putgd-cli','putgd-launcher','putgd-lab-secret-bridge','putgd-lab-proton-secrets']:helpers.append({'pid':int(proc.name),'executable':exe})
    except PermissionError:
     comm=(proc/'comm').read_text().strip()
     if comm.startswith('putgd'):raise
    except FileNotFoundError:pass
   row={'elapsed':time.monotonic()-started,'phase':phase,'sample':sample,'productHelpers':helpers};stream.write(json.dumps(row)+'\n');stream.flush();result['samples']+=1
   if phase.startswith('idle-'):
    w=result['windows'].setdefault(phase,{'samples':0,'maxRssBytes':0,'maxSwapBytes':0,'maxProcessCount':0,'maxEscaped':0,'anyProductHelper':False})
    w['samples']+=1;w['maxRssBytes']=max(w['maxRssBytes'],sample['totals']['rssBytes']);w['maxSwapBytes']=max(w['maxSwapBytes'],sum(x['swapBytes'] for x in sample['processes']));w['maxProcessCount']=max(w['maxProcessCount'],sample['processCount']);w['maxEscaped']=max(w['maxEscaped'],sample['escapedProcessCount']);w['anyProductHelper']|=bool(helpers)
   time.sleep(.2)
 result['passed']=True
except BaseException as e:
 result['failureType']=type(e).__name__;raise
finally:
 result['elapsedSeconds']=time.monotonic()-started;(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
