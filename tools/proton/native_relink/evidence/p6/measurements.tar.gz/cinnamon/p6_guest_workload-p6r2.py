import hashlib,json,os,shlex,struct,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'tools/lab'))
import lab,proton_lend_smoke
root=Path(__file__).parent;run=Path(os.environ['PUTGD_LAB_RUN']);reference=os.environ['PUTGD_LAB_PROTON_REFERENCE'];out=run/'p6r2';out.mkdir(mode=0o700,exist_ok=False)
smoke=proton_lend_smoke.Smoke(run,reference);result={'schemaVersion':1,'passed':False,'helperSha256':'9fd4d72f86352cfcf2c8b6ba1db4102ed6f7b22660077698c700989e9fda8586','windows':[],'accountsOrSessionsRetained':False};watch=False
original_step=smoke.step
def step(name,**fields):
 fields.pop('accountEmail',None)
 entry=dict(proton_lend_smoke.scrub(fields),step=name,at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat());smoke.result['steps'].append(entry);lab.write_json(out/'proton-smoke.json',smoke.result);print(json.dumps(entry),flush=True)
smoke.step=step
try:
 lab.guest_preflight(run,apply=False,stage='p6r2-functional-before')
 lab.ssh(run,'umask 077; mkdir -p "$HOME/putgd-lab/p6r2"; printf functional > "$HOME/putgd-lab/p6r2/phase"\n')
 for src,dst in [(root/'tests/performance/bench_ui_process.py','bench_ui_process.py'),(root/'guest_watch-corrected.py','guest_watch.py'),(root/'close_ui.py','close_ui.py')]:lab.put(run,str(src),'putgd-lab/p6r2/'+dst)
 lab.guest_session(run,'busctl --user set-property org.a11y.Bus /org/a11y/bus org.a11y.Status IsEnabled b true\nbusctl --user set-property org.a11y.Bus /org/a11y/bus org.a11y.Status ScreenReaderEnabled b true\n')
 lab.acceptance_preflight(run,apply=False,stage='p6r2-accessible-start')
 lab.guest_session(run,'export QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1\nnohup putgd-launcher --background > \"$HOME/putgd-lab/p6r2-start.log\" 2>&1 < /dev/null &\n')
 deadline=time.monotonic()+30
 while True:
  try:lab.cli(run,'capabilities');break
  except lab.LabError:
   if time.monotonic()>deadline:raise
   time.sleep(.3)
 lab.verify_running_app(run)
 smoke.configure()
 identity_code="""import json,os,socket,struct,sys,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.home()/'putgd-lab/p6r2'))
from bench_ui_process import identity
p='/run/user/'+str(os.getuid())+'/putgd/session.sock';assert len(p.encode())<=107
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(p);pid,uid,gid=struct.unpack('3i',s.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12));s.close();assert uid==os.getuid()
f=Path('/usr/libexec/putgd/proton/putgd-proton-runtime');d=hashlib.sha256(f.read_bytes()).hexdigest();assert d=='9fd4d72f86352cfcf2c8b6ba1db4102ed6f7b22660077698c700989e9fda8586'
print(json.dumps({'resident':identity(pid),'socket':p,'helperSha256':d}))
"""
 result.update(json.loads(lab.guest_session(run,'python3 - <<\'PY\'\n'+identity_code+'PY\n')));result['build']=json.loads(lab.guest_session(run,'putgd --version-json\n'));who=result['resident'];result['package']=json.loads((run/'package.json').read_text())
 cmd=['python3','$HOME/putgd-lab/p6r2/guest_watch.py','--pid',str(who['pid']),'--ticks',str(who['startTicks']),'--output','$HOME/putgd-lab/p6r2/watch']
 lab.guest_session(run,'nohup '+ ' '.join(x if x.startswith('$HOME') else shlex.quote(x) for x in cmd)+' > "$HOME/putgd-lab/p6r2/watch.log" 2>&1 < /dev/null &\n');watch=True
 smoke.folder();smoke.check();smoke.upload()
 smoke.sharing('history.share');shared=smoke.expect(smoke.sharing('history.inspectLink'),'shared')
 smoke.cli('ui.show',{'view':'history'});time.sleep(2);result['sharedVisual']=lab.screenshot(run,'p6r2-shared')
 smoke.expect(smoke.sharing('history.revokeLink'),'revoked');detail=smoke.cli('history.detail',{'id':smoke.result['historyId']});assert detail.get('shareStatus')=='revoked' and detail.get('uploadStatus')=='uploaded'
 time.sleep(1);result['revokedVisual']=lab.screenshot(run,'p6r2-revoked');result['operationId']=smoke.result['operationId'];result['historyId']=smoke.result['historyId'];result['functionalPassed']=True
 result['closeActionExit']=int(lab.guest_session(run,'set +e\ntimeout 10s python3 "$HOME/putgd-lab/p6r2/close_ui.py" > "$HOME/putgd-lab/p6r2/close-action.log" 2>&1\nprintf \"%s\\n\" \"$?\"\n').strip())
 deadline=time.monotonic()+30
 while True:
  d=smoke.cli('ui.snapshot')['diagnostics']
  if d.get('ui',{}).get('pid',0)==0:
   assert d['ui'].get('lastExit',{}).get('code')==0;break
  if time.monotonic()>deadline:raise RuntimeError('UI helper did not exit')
  time.sleep(.5)
 time.sleep(30)
 (out/'functional.json').write_text(json.dumps(result,indent=2)+'\n');lab.put(run,str(out/'functional.json'),'putgd-lab/p6r2/functional.json')
 for n in [1,2]:
  label='idle-'+str(n);lab.ssh(run,'printf '+label+' > "$HOME/putgd-lab/p6r2/phase"\n');lab.guest_preflight(run,apply=False,stage='p6r2-'+label+'-before')
  command=['python3','~/putgd-lab/p6r2/bench_ui_process.py','--mode','split','--app','/usr/bin/putgd','--cli','/usr/bin/putgd-cli','--helper','/usr/bin/putgd-ui','--source-revision',result['build']['gitCommit'],'--pid',str(who['pid']),'--start-ticks',str(who['startTicks']),'--socket',result['socket'],'--seconds','301','--interval','5','--label',label,'--acceptance-receipt','~/putgd-lab/p6r2/functional.json','--output','~/putgd-lab/p6r2/'+label]
  shell=' '.join(x if x.startswith('~/') else shlex.quote(x) for x in command)
  lab.guest_session(run,shell+' > "$HOME/putgd-lab/p6r2/'+label+'.log" 2>&1\n',timeout=410)
  for name in ['results.json','samples.jsonl']:lab.get(run,'putgd-lab/p6r2/'+label+'/'+name,str(out/(label+'-'+name)))
  r=json.loads((out/(label+'-results.json')).read_text());rows=[json.loads(x) for x in (out/(label+'-samples.jsonl')).read_text().splitlines()];elapsed=rows[-1]['elapsedSeconds']-rows[0]['elapsedSeconds'];ticks=100
  ticks=int(lab.ssh(run,'getconf CLK_TCK\n').strip());cpu=(sum(p['cpuTicks'] for p in rows[-1]['processes'])-sum(p['cpuTicks'] for p in rows[0]['processes']))/ticks/elapsed*100
  gates={'observerPassed':r['passed'],'rssAtMost40MiB':max(x['totals']['rssBytes'] for x in rows)<=40*1048576,'cpuBelowHalfPercentOneCore':cpu<.5,'zeroSwap':all(all(p['swapBytes']==0 for p in x['processes']) for x in rows),'noHelpersOrEscapes':all(x['processCount']==1 and x['uiProcessCount']==0 and x['escapedProcessCount']==0 for x in rows),'durationAtLeast300Seconds':elapsed>=300}
  result['windows'].append({'window':n,'seconds':elapsed,'rssPeakMiB':max(x['totals']['rssBytes'] for x in rows)/1048576,'cpuPercentOneCore':cpu,'gates':gates});assert all(gates.values()),'Resource gate failed'
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');lab.guest_preflight(run,apply=False,stage='p6r2-'+label+'-after')
 lab.ssh(run,'touch "$HOME/putgd-lab/p6r2/watch-stop"\n');time.sleep(1);lab.get(run,'putgd-lab/p6r2/watch/results.json',str(out/'continuous-watch.json'));w=json.loads((out/'continuous-watch.json').read_text());assert w['passed']
 for label in ['idle-1','idle-2']:
  x=w['windows'][label];assert x['samples']>=1000 and x['maxRssBytes']<=40*1048576 and x['maxSwapBytes']==0 and x['maxProcessCount']==1 and x['maxEscaped']==0 and not x['anyProductHelper']
 result['sameUsedResidentForBothWindows']=True;result['continuousFamilyAndEscapedHelperScanPassed']=True;result['passed']=True
except BaseException as e:
 result['failureType']=type(e).__name__
 try:result['failureVisual']=lab.screenshot(run,'p6r2-failure')
 except BaseException:pass
 raise
finally:
 if watch:
  try:lab.ssh(run,'touch "$HOME/putgd-lab/p6r2/watch-stop"\n')
  except BaseException:pass
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');smoke.finish()
