import gi,json,os,pathlib
import time
gi.require_version('Atspi','2.0')
from gi.repository import Atspi
pids=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:
  if os.readlink(p/'exe')=='/usr/bin/putgd-ui':pids.append(int(p.name))
 except OSError:pass
root=Atspi.get_desktop(0);targets=[]
def walk(n,depth=0):
 if depth>20:return
 try:
  if n.get_name()=='Close window' and n.get_role_name() in ('button','push button') and n.get_state_set().contains(Atspi.StateType.SHOWING):targets.append(n)
  for i in range(n.get_child_count()):walk(n.get_child_at_index(i),depth+1)
 except Exception:pass
for n in range(root.get_child_count()):
 app=root.get_child_at_index(n)
 try:
  if app.get_process_id() in pids:walk(app)
 except Exception:pass
if len(targets)!=1:raise SystemExit('Expected exactly one owned visible Close window button')
a=targets[0].get_action_iface();assert a.get_n_actions()>0;assert a.do_action(0)
print(json.dumps({'ownedUiPid':pids,'closeActionInvoked':True}))
